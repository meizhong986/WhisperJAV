"""
WhisperJAV PyWebView GUI Module

Modern web-based GUI for WhisperJAV using PyWebView.
Maintains thin wrapper pattern - all functionality remains in CLI.
"""

__version__ = "0.1.0"
