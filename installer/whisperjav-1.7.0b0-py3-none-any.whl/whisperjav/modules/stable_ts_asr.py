#!/usr/bin/env python3
"""Stable-ts ASR wrapper for WhisperJAV - V3 Architecture."""

import sys
import os
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Union, Tuple
import stable_whisper
from dataclasses import dataclass
import traceback
import logging
import torch
import warnings
import soundfile as sf
import librosa

try:
    from huggingface_hub import snapshot_download
except Exception:  # pragma: no cover - optional dependency guard
    snapshot_download = None

from whisperjav.utils.logger import logger
from whisperjav.utils.device_detector import get_best_device
from contextlib import contextmanager, redirect_stdout, redirect_stderr

# Suppress specific warnings from stable_whisper
warnings.filterwarnings("ignore", message="Cannot clamp due to missing/no word-timestamps")
warnings.filterwarnings("ignore", message="Failed to transcribe audio. Result contains no text")
warnings.filterwarnings("ignore", message="Failed to translate audio. Result contains no text")

def _is_silero_vad_cached(repo_or_dir: str) -> bool:
    """
    Check if a specific silero-vad version is already cached by torch.hub.

    Args:
        repo_or_dir: Repository string (e.g., "snakers4/silero-vad:v3.1")

    Returns:
        True if the exact version is cached, False otherwise
    """
    try:
        # Get torch hub cache directory
        hub_dir = torch.hub.get_dir()

        # Parse repo and version
        if ':' in repo_or_dir:
            repo_name, version = repo_or_dir.rsplit(':', 1)
        else:
            repo_name = repo_or_dir
            version = 'master'  # Default branch

        # Construct expected cache path
        # torch.hub caches repos as: hub_dir/owner_repo_branch
        repo_safe = repo_name.replace('/', '_')
        cached_repo_path = Path(hub_dir) / f"{repo_safe}_{version}"

        if cached_repo_path.exists():
            logger.debug(f"Silero VAD {version} found in cache: {cached_repo_path}")
            return True
        else:
            logger.debug(f"Silero VAD {version} NOT in cache, will download")
            return False
    except Exception as e:
        logger.warning(f"Error checking silero-vad cache: {e}")
        return False  # If we can't check, assume not cached


@contextmanager
def suppress_output():
    """Suppress both stdout and stderr."""
    with open(os.devnull, 'w') as devnull:
        with redirect_stdout(devnull), redirect_stderr(devnull):
            yield


@dataclass
class LexicalSets:
    """Japanese lexical sets for subtitle processing."""
    sentence_endings: List[str] = None
    polite_forms: List[str] = None
    verb_continuations: List[str] = None
    noun_phrases: List[str] = None
    vocal_extensions: List[str] = None
    initial_fillers: List[str] = None
    non_lexical_sounds: List[str] = None

    def __post_init__(self):
        self.sentence_endings = self.sentence_endings or ['よ', 'ね', 'わ', 'の', 'ぞ', 'ぜ', 'な', 'か', 'かしら', 'かな']
        self.polite_forms = self.polite_forms or ['ます', 'です', 'ました', 'でしょう', 'ましょう', 'ません']
        self.verb_continuations = self.verb_continuations or ['て', 'で', 'た', 'ず', 'ちゃう', 'じまう']
        self.noun_phrases = self.noun_phrases or ['の', 'こと', 'もの', 'とき', 'ところ']
        self.vocal_extensions = self.vocal_extensions or ['~', 'ー', 'ぁ', 'ぃ', 'ぅ', 'ぇ', 'ぉ']
        self.initial_fillers = self.initial_fillers or ['あの', 'えっと', 'えー', 'まあ', 'なんか']
        self.non_lexical_sounds = self.non_lexical_sounds or ['ああ', 'う', 'ん', 'はぁ', 'ふぅ', 'くっ']


class StableTSASR:
    """Stable-ts ASR wrapper supporting both standard and turbo modes with V3 architecture."""
    
    # Define which parameters are valid for each backend
    STANDARD_WHISPER_PARAMS = {
        # Transcribe parameters
        'temperature', 'compression_ratio_threshold', 'logprob_threshold',
        'no_speech_threshold', 'condition_on_previous_text', 'initial_prompt',
        'carry_initial_prompt', 'word_timestamps', 'prepend_punctuations',
        'append_punctuations', 'clip_timestamps', 'hallucination_silence_threshold',
        # Decode options
        'task', 'language', 'sample_len', 'best_of', 'beam_size', 'patience',
        'length_penalty', 'prompt', 'prefix', 'suppress_tokens', 'suppress_blank',
        'without_timestamps', 'max_initial_timestamp', 'fp16',
        # Stable-ts specific
        'regroup', 'vad', 'vad_threshold'
    }
    
    FASTER_WHISPER_PARAMS = {
        # Core parameters that faster_whisper accepts
        'task', 'language', 'temperature', 'beam_size', 'best_of', 'patience',
        'length_penalty', 'compression_ratio_threshold', 'no_speech_threshold',
        'condition_on_previous_text', 'initial_prompt', 'prefix',
        'suppress_blank', 'suppress_tokens', 'without_timestamps',
        'max_initial_timestamp', 'word_timestamps',
        # VAD parameters
        'vad', 'vad_threshold',
        # Stable-ts specific
        'regroup',
        # Faster-whisper specific
        'repetition_penalty', 'no_repeat_ngram_size',
        # Inference control
        'batch_size', 'chunk_length'
    }
    
    def __init__(self,
                 model_config: Dict,
                 params: Dict,
                 task: str,
                 turbo_mode: bool = False):
        """
        Initialize Stable-ts ASR with structured V3 parameters.
        
        Args:
            model_config: Model configuration containing model_name, device, compute_type
            params: Structured parameters with decoder, vad, and provider sections
            task: The ASR task ('transcribe' or 'translate')
            turbo_mode: Whether to use faster-whisper backend (True) or standard whisper (False)
        """
        # --- V3 PARAMETER UNPACKING ---
        self.model_name = model_config.get("model_name", "large-v2")
        # Use smart device detection: CUDA → MPS → CPU
        self.device = model_config.get("device", get_best_device())
        self.compute_type = model_config.get("compute_type", "float16")
        self.turbo_mode = turbo_mode
        self.model_repo = model_config.get("hf_repo")
        if not self.model_repo:
            self.model_repo = self._derive_model_repo(self.model_name)

        # Store structured parameters directly - trust the tuner
        self.decoder_params = params.get("decoder", {})
        self.provider_params = params.get("provider", {})
        self.task = task
        self.language = self.decoder_params.get("language", "ja")

        # Extract VAD repo from provider params (packed handling in tuner)
        # Fallback to old hardcoded logic if not provided (backward compatibility)
        self.vad_repo = self.provider_params.get("vad_repo", None)
        if not self.vad_repo:
            self.vad_repo = "snakers4/silero-vad" if turbo_mode else "snakers4/silero-vad:v4.0"
            logger.warning(f"VAD repo not found in config, using fallback: {self.vad_repo}")

        # Extract stable-ts specific options if provided
        self.stable_ts_options = params.get("stable_ts", {})
        
        # --- END V3 PARAMETER UNPACKING ---

        self.lexical_sets = LexicalSets()
        
        # Pre-cache the appropriate Silero VAD version
        self._precache_silero_vad()
        
        # Load model
        logger.debug(f"Loading Stable-TS model: {self.model_name}")
        if self.turbo_mode:
            # Use faster_whisper backend with guardrails for corrupted caches
            self._prefetch_faster_whisper_weights()
            self.model = self._load_faster_whisper_with_retry()
        else:
            # Use standard whisper backend
            self.model = stable_whisper.load_model(self.model_name, device=self.device)
            
        # Log active sensitivity parameters
        self._log_sensitivity_parameters()
    
    def _precache_silero_vad(self):
        """Pre-cache the appropriate Silero VAD version for stable-ts to use."""
        if hasattr(self, '_vad_precached') and self._vad_precached:
            logger.debug("VAD already pre-cached for this instance")
            return

        # Use repo from config (resolved by TranscriptionTuner, or fallback from __init__)
        logger.debug(f"Pre-caching Silero VAD: {self.vad_repo}")

        try:
            # Check if already cached to avoid unnecessary download
            is_cached = _is_silero_vad_cached(self.vad_repo)

            # Only force reload if not cached (downloads specific version if needed)
            torch.hub.load(
                repo_or_dir=self.vad_repo,  # Config-driven, not hardcoded
                model="silero_vad",
                force_reload=not is_cached,  # Use cache if available
                onnx=False
            )
            self._vad_precached = True
            status = "from cache" if is_cached else "downloaded"
            logger.debug(f"Successfully loaded VAD from {self.vad_repo} ({status})")
        except Exception as e:
            logger.warning(f"Failed to pre-cache Silero VAD: {e}")

    def _derive_model_repo(self, model_name: Optional[str]) -> Optional[str]:
        """Best-effort mapping from faster-whisper size to Hugging Face repo."""
        if not model_name:
            return None

        try:
            potential_path = Path(model_name).expanduser()
            if potential_path.exists():
                # Explicit local path
                return None
        except Exception:
            pass

        if "/" in model_name:
            return model_name

        normalized = model_name
        if not normalized.startswith("faster-whisper-"):
            normalized = f"faster-whisper-{normalized}"
        return f"Systran/{normalized}"

    def _prefetch_faster_whisper_weights(self, force: bool = False) -> None:
        """Ensure faster-whisper weights exist locally before loading."""
        if not self.turbo_mode or not self.model_repo or snapshot_download is None:
            return

        try:
            snapshot_dir = snapshot_download(
                repo_id=self.model_repo,
                resume_download=not force,
                force_download=force,
                local_files_only=False,
                allow_patterns=[
                    "*.bin",
                    "*.json",
                    "*.txt",
                    "*.model",
                    "*.vocab*"
                ],
            )
            model_bin = Path(snapshot_dir) / "model.bin"
            if not model_bin.exists():
                if force:
                    logger.warning(
                        "model.bin still missing after forced download of %s", self.model_repo
                    )
                else:
                    logger.warning(
                        "model.bin missing in %s; forcing clean download", snapshot_dir
                    )
                    self._prefetch_faster_whisper_weights(force=True)
        except Exception as e:
            logger.warning(f"Failed to prefetch faster-whisper weights ({self.model_repo}): {e}")

    def _load_faster_whisper_with_retry(self):
        """Load faster-whisper with a cache refresh fallback."""
        last_exc: Optional[Exception] = None
        for attempt in range(2):
            try:
                return stable_whisper.load_faster_whisper(
                    self.model_name,
                    device=self.device,
                    compute_type=self.compute_type
                )
            except (RuntimeError, OSError) as exc:
                last_exc = exc
                message = str(exc).lower()
                if attempt == 0 and "model.bin" in message:
                    logger.warning(
                        "Detected corrupted faster-whisper cache (%s). Re-downloading weights and retrying once.",
                        exc
                    )
                    self._prefetch_faster_whisper_weights(force=True)
                    continue
                raise

        if last_exc:
            raise last_exc
    
    def _log_sensitivity_parameters(self):
        """Log the sensitivity-related parameters for debugging."""
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug("--- StableTSASR Initialized with V3 Parameters ---")
            logger.debug(f"  Model: {self.model_name}")
            logger.debug(f"  Device: {self.device}")
            logger.debug(f"  Turbo Mode: {self.turbo_mode}")
            logger.debug(f"  Temperature: {self.decoder_params.get('temperature', 'default')}")
            logger.debug(f"  Beam Size: {self.decoder_params.get('beam_size', 'default')}")
            logger.debug(f"  Best Of: {self.decoder_params.get('best_of', 'default')}")
            logger.debug(f"  Patience: {self.decoder_params.get('patience', 'default')}")
            logger.debug(f"  Length Penalty: {self.decoder_params.get('length_penalty', 'default')}")
            logger.debug(f"  No Speech Threshold: {self.provider_params.get('no_speech_threshold', 'default')}")
            logger.debug(f"  Compression Ratio Threshold: {self.provider_params.get('compression_ratio_threshold', 'default')}")
            if not self.turbo_mode:
                logger.debug(f"  Logprob Threshold: {self.provider_params.get('logprob_threshold', 'default')}")
            logger.debug("----------------------------------------------------")
    
    def _filter_parameters_for_backend(self, params: Dict) -> Dict:
        """Filter parameters based on which backend is being used."""
        if self.turbo_mode:
            valid_params = self.FASTER_WHISPER_PARAMS
            backend_name = "faster_whisper"
        else:
            valid_params = self.STANDARD_WHISPER_PARAMS
            backend_name = "standard_whisper"
        
        # Filter out invalid parameters
        filtered = {}
        removed = []
        
        for key, value in params.items():
            if key in valid_params:
                filtered[key] = value
            else:
                removed.append(key)
        
        if removed and logger.isEnabledFor(logging.DEBUG):
            logger.debug(f"Removed {len(removed)} parameters not supported by {backend_name}: {removed}")
        
        return filtered
    
    def _prepare_transcribe_parameters(self, **kwargs) -> Dict:
            """Prepare all parameters for transcription - simplified for V3."""
            # Start with decoder and provider params (trusting they're pre-structured)
            params = {}
            params.update(self.decoder_params)
            params.update(self.provider_params)
            
            # Add stable-ts specific options
            if self.stable_ts_options:
                params.update(self.stable_ts_options)
            
            # Add runtime parameters
            params.update(kwargs)
            
            # Ensure task and language are set
            params['task'] = kwargs.get('task', self.task)
            params['language'] = self.language
            
            # Temperature type conversion if needed
            if 'temperature' in params:
                temp = params['temperature']
                if isinstance(temp, list):
                    params['temperature'] = tuple(temp)
                elif isinstance(temp, (int, float)):
                    params['temperature'] = (float(temp),)
            
            # Ensure VAD is enabled (since it's always on for stable-ts)
            if 'vad' not in params:
                params['vad'] = True
            if 'vad_threshold' not in params:
                params['vad_threshold'] = 0.35  # Default VAD threshold
            
            # Filter based on backend - this is essential!
            params = self._filter_parameters_for_backend(params)
            
            # FIX: ctranslate2 compatibility - convert tuples to lists where needed
            if self.turbo_mode:
                params = self._ensure_ctranslate2_compatibility(params)
            
            # Special handling for turbo mode
            if self.turbo_mode:
                # Cap beam_size if too high
                if 'beam_size' in params and params['beam_size'] > 5:
                    logger.debug(f"Turbo mode: Capping beam_size from {params['beam_size']} to 5")
                    params['beam_size'] = 5

                # Force batch_size=8 for BatchedInferencePipeline
                logger.debug("Turbo mode: Forcing batch_size=8 for batched inference")
                params['batch_size'] = 8                
                    
                return params
            else:
                # For original Whisper, we need to handle it differently
                # But now we trust that params are already properly structured
                # Just ensure we have the ignore_compatibility flag
                params['ignore_compatibility'] = True
            params['verbose'] = None  # Suppress progress
            return params

    def _ensure_ctranslate2_compatibility(self, params: Dict) -> Dict:
        """
        Ensure parameter types are compatible with ctranslate2 backend used by faster-whisper.
        
        ctranslate2 is very strict about parameter types and will reject incompatible arguments.
        """
        # Convert tuples to lists where ctranslate2 expects lists
        if 'suppress_tokens' in params and isinstance(params['suppress_tokens'], tuple):
            params['suppress_tokens'] = list(params['suppress_tokens'])
            logger.debug(f"Converted suppress_tokens from tuple to list for ctranslate2 compatibility")
        
        # Ensure no_repeat_ngram_size is int (ctranslate2 requirement)
        if 'no_repeat_ngram_size' in params:
            try:
                params['no_repeat_ngram_size'] = int(params['no_repeat_ngram_size'])
                logger.debug(f"Ensured no_repeat_ngram_size is int for ctranslate2")
            except (ValueError, TypeError):
                logger.warning(f"Invalid no_repeat_ngram_size value, removing: {params['no_repeat_ngram_size']}")
                del params['no_repeat_ngram_size']
        
        return params

    def _load_audio_as_numpy(self, audio_path: Path) -> np.ndarray:
        """Load audio file as numpy array to avoid FFmpeg subprocess calls.
        
        This method loads audio directly into memory, preventing stable-whisper
        from spawning FFmpeg subprocesses that create visible console windows.
        """
        try:
            if audio_path.suffix.lower() == '.wav':
                # Use soundfile for WAV files (faster, no FFmpeg)
                data, sr = sf.read(str(audio_path), dtype='float32', always_2d=False)
                
                # Convert to mono if stereo
                if data.ndim > 1:
                    data = data.mean(axis=1)
                
                # Resample to 16kHz if needed (Whisper requirement)
                if sr != 16000:
                    data = librosa.resample(data, orig_sr=sr, target_sr=16000)
                
                logger.debug(f"Loaded {audio_path.name} as numpy array (WAV path, sr={sr}->16000)")
                return data
            else:
                # Use librosa for other formats (MP3, MP4, etc.)
                # This might still use FFmpeg internally, but only once per file
                data, sr = librosa.load(str(audio_path), sr=16000, mono=True)
                logger.debug(f"Loaded {audio_path.name} as numpy array (librosa path)")
                return data
                
        except Exception as e:
            logger.warning(f"Failed to load audio as numpy array: {e}")
            # Return None to signal fallback to file path method
            return None

    def transcribe(self, audio_path: Union[str, Path], **kwargs) -> stable_whisper.WhisperResult:
        """Transcribe audio file with full parameter validation and backend compatibility."""
        audio_path = Path(audio_path)
        logger.debug(f"Transcribing: {audio_path.name}")
        
        # Prepare and validate all parameters
        final_params = self._prepare_transcribe_parameters(**kwargs)
        
        # Extract task parameter for later use
        task = final_params.get('task', self.task)

        # Log final parameters if debug enabled
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug(f"Backend: {'faster_whisper' if self.turbo_mode else 'standard_whisper'}")
            logger.debug(f"Task: {task}")
            logger.debug(f"Final transcription parameters: {final_params}")
        
        try:
            # Load audio as numpy array to avoid FFmpeg subprocess windows
            audio_input = self._load_audio_as_numpy(audio_path)
            
            if audio_input is None:
                # Fallback to file path if numpy loading failed
                logger.debug("Using file path for transcription (fallback)")
                audio_input = str(audio_path)
            else:
                logger.debug("Using numpy array for transcription (no FFmpeg windows)")
            
            # Suppress warnings during transcription
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=UserWarning)
                
                result = self.model.transcribe(audio_input, **final_params)
                
        except TypeError as e:
            # If we still get a parameter error, log details and retry with minimal params
            logger.error(f"Parameter error: {e}")
            logger.debug(f"Failed parameters: {final_params}")
            
            # Fallback to minimal parameters
            minimal_params = {
                'task': task,
                'language': self.language,
                'temperature': (0.0,),
                'beam_size': 5,
                'verbose': None
            }
            
            # Only add ignore_compatibility for original whisper
            if not self.turbo_mode:
                minimal_params['ignore_compatibility'] = True
            
            logger.warning(f"Retrying with minimal parameters: {minimal_params}")
            
            # Try with minimal params, still using numpy if possible
            audio_input = self._load_audio_as_numpy(audio_path)
            if audio_input is None:
                audio_input = str(audio_path)
            
            # Suppress warnings during fallback too
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=UserWarning)
                result = self.model.transcribe(audio_input, **minimal_params)
                
        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            logger.debug(traceback.format_exc())
            raise
        
        # Apply post-processing only for Japanese transcription
        if task == 'transcribe':
            self._postprocess(result)
        else:
            logger.debug(f"Skipping Japanese post-processing for task='{task}' (English output)")
        
        return result

    def transcribe_to_srt(self, 
                         audio_path: Union[str, Path], 
                         output_srt_path: Union[str, Path],
                         **kwargs) -> Path:
        """Transcribe audio and save as SRT file."""
        # Ensure task is passed through to transcribe method
        if 'task' not in kwargs:
            kwargs['task'] = self.task
        
        result = self.transcribe(audio_path, **kwargs)
        
        final_output_path = Path(output_srt_path)
        self._save_to_srt(result, final_output_path)
        return final_output_path
    
    def _postprocess_japanese_dialogue(self,
                                      result: stable_whisper.WhisperResult, 
                                      preset: str = "default") -> stable_whisper.WhisperResult:
        """
        Applies a unified, multi-pass regrouping strategy to a stable-ts result
        for optimal Japanese conversational dialogue segmentation.

        Args:
            result: The WhisperResult object from a stable-ts transcription.
            preset: A preset strategy: "default", "high_moan", or "narrative".

        Returns:
            The modified WhisperResult object after post-processing.
        """
        logger.debug(f"Applying Japanese post-processing with '{preset}' preset.")
        
        if not result.segments:
            logger.debug("No segments found in transcription result. Skipping post-processing.")
            return

        # --- Preset Parameters ---
        gap_threshold = {
            "default": 0.3,
            "high_moan": 0.1,
            "narrative": 0.4,
        }.get(preset, 0.3)

        segment_length = {
            "default": 35,
            "high_moan": 25,
            "narrative": 45,
        }.get(preset, 35)

        # --- Linguistic Ending Clusters ---
        BASE_ENDINGS = ['ね', 'よ', 'わ', 'の', 'ぞ', 'ぜ', 'さ', 'か', 'かな', 'な']
        MODERN_ENDINGS = ['じゃん', 'っしょ', 'んだ', 'わけ', 'かも', 'だろう']
        KANSAI_ENDINGS = ['わ', 'で', 'ねん', 'な', 'や']
        FEMININE_ENDINGS = ['かしら', 'こと', 'わね', 'のよ']
        MASCULINE_ENDINGS = ['ぜ', 'ぞ', 'だい', 'かい']
        
        POLITE_FORMS = ['です', 'ます', 'でした', 'ましょう', 'ませんか']
        CASUAL_CONTRACTIONS = ['ちゃ', 'じゃ', 'きゃ', 'にゃ', 'ひゃ', 'みゃ', 'りゃ']
        QUESTION_PARTICLES = ['の', 'か']

        FINAL_ENDINGS_TO_LOCK = list(set(
            BASE_ENDINGS +
            MODERN_ENDINGS +
            KANSAI_ENDINGS +
            FEMININE_ENDINGS +
            MASCULINE_ENDINGS
        ))

        AIZUCHI_FILLERS = [
            'あの', 'あのー', 'ええと', 'えっと', 'まあ', 'なんか', 'こう',
            'うん', 'はい', 'ええ', 'そう', 'えっ', 'あっ',
        ]

        EXPRESSIVE_EMOTIONS = ['ああ', 'うう', 'ええ', 'おお', 'はあ', 'ふう', 'あっ', 
            'うっ', 'はっ', 'ふっ', 'んっ'
        ]

        CONVERSATIONAL_VERBAL_ENDINGS = [
            'てる',  # from -te iru
            'でる',  # from -de iru
            'ちゃう', # from -te shimau
            'じゃう', # from -de shimau
            'とく',  # from -te oku
            'どく',  # from -de oku
            'んない'  # from -ranai
        ]

        try:
            # --- Pass 1: Remove Fillers and Aizuchi ---
            logger.debug("Phase 1: Sanitization (Fillers and Aizuchi Removal)")
            result.remove_words_by_str(AIZUCHI_FILLERS, case_sensitive=False, strip=True, verbose=False)

            # --- Pass 2: Structural Anchoring ---
            logger.debug("Phase 2: Structural Anchoring")

            # 2a: Split by strong punctuation marks (full-width and half-width)
            result.regroup("sp= 。 / ？ / ！ / … / ． /. /? /!+1")

            # 2b: Lock known structural boundaries
            result.lock(startswith=['「', '『'], left=True, right=False, strip=False)
            result.lock(endswith=['」', '』'], right=True, left=False, strip=False)
            result.lock(endswith=FINAL_ENDINGS_TO_LOCK, right=True, left=False, strip=True)
            result.lock(endswith=POLITE_FORMS, right=True, strip=True)
            result.lock(endswith=QUESTION_PARTICLES, right=True, strip=True)

            for ending in CONVERSATIONAL_VERBAL_ENDINGS:
                result.custom_operation('word', 'end', ending, 'lockright', word_level=True)
            
            # 2c: Lock expressive/emotive interjections
            result.lock(
                startswith=EXPRESSIVE_EMOTIONS,
                endswith=EXPRESSIVE_EMOTIONS,
                left=True,
                right=True
            )

            # --- Pass 3: Merge & Heuristic Refinement ---
            logger.debug("Phase 3: Heuristic-Based Merging & Refinement")
            result.merge_by_punctuation(
                punctuation=['、', '，', ','],
                max_chars=40,
                max_words=15
            )

            result.merge_by_gap(
                min_gap=gap_threshold,
                max_chars=40,
                max_words=15,
                is_sum_max=True
            )

            # Optional: Apply split by long pause
            result.split_by_gap(max_gap=1.2)

            # --- Pass 4: Final Cleanup & Formatting ---
            logger.debug("Phase 4: Final Cleanup & Formatting")
            result.split_by_length(
                max_chars=segment_length,
                max_words=15,
                even_split=False
            )

            # Proactive safety: split long segments
            result.split_by_duration(max_dur=8.5, even_split=False, lock=True)

            result.reassign_ids()
            
            logger.debug("Japanese post-processing complete.")
            return result

        except Exception as e:
            # Change ERROR to DEBUG for word timestamp issues
            error_msg = str(e).lower()
            if any(term in error_msg for term in ['word timestamp', 'word_level', 'word-level', 'missing word']):
                logger.debug(f"Japanese post-processing skipped - no word timestamps: {e}")
            else:
                logger.error(f"An error occurred during Japanese post-processing: {e}")
            logger.debug(traceback.format_exc())

    def _postprocess(self, result):
        """Apply advanced Japanese-specific post-processing using embedded logic."""
        logger.debug("Applying refined Japanese post-processing of segment results")
        
        # Check if we have any segments to process
        if not result.segments:
            logger.debug("No segments found in transcription result")
            return
            
        try:
            self._postprocess_japanese_dialogue(result, preset="default")
            logger.debug("Post-processing segment results completed successfully")
        except Exception as e:
            # Log word timestamp errors at DEBUG level instead of ERROR
            error_msg = str(e).lower()
            if any(term in error_msg for term in ['word timestamp', 'word_level', 'word-level', 'missing word']):
                logger.debug(f"Post-processing skipped - no word timestamps: {e}")
            else:
                # Keep real errors as ERROR level
                logger.error(f"Post-processing segment results failed: {e}")
                logger.debug(traceback.format_exc())

    def _save_to_srt(self, result: stable_whisper.WhisperResult, output_path: Path):
        """Save transcription result to SRT file."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        logger.debug(f"Saving SRT to: {output_path}")

        # Suppress output from stable_whisper
        with suppress_output():
            result.to_srt_vtt(str(output_path),
                              word_level=False,
                              segment_level=True,
                              strip=True)

    def cleanup(self):
        """
        Release GPU/CPU memory by unloading models.

        This should be called when the ASR instance is no longer needed,
        especially in batch processing scenarios where models need to be
        swapped between passes.
        """
        import gc

        logger.debug(f"Cleaning up {self.__class__.__name__} resources...")

        # Delete the stable-ts model (either standard or faster-whisper backend)
        if hasattr(self, 'model'):
            del self.model
            self.model = None
            logger.debug("Stable-ts model unloaded")

        # Clear CUDA cache if available
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            logger.debug("CUDA cache cleared")

        # Force garbage collection
        gc.collect()

        logger.debug(f"{self.__class__.__name__} cleanup complete")
