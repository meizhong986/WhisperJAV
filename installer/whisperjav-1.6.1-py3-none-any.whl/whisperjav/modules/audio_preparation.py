"""Audio preparation module."""

class AudioPreparation:
    """Prepare audio for transcription."""
    pass
