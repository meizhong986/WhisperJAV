# whisperjav/modules/repetition_cleaner.py

# FINAL FIX: Implemented a comprehensive solution based on user feedback.

# The logic is now more aggressive in cleaning and less aggressive in protection.



import re

import regex

from collections import Counter

from typing import Dict, List, Tuple, Set, Optional

import numpy as np

from whisperjav.utils.logger import logger

from whisperjav.config.sanitization_constants import RepetitionConstants





class RepetitionCleaner:

    """

    FINAL, HARDENED VERSION.

    This cleaner uses a single, curated list of safe patterns to aggressively clean

    extreme repetitions while avoiding the data corruption bugs.

    """



    def __init__(self, constants: RepetitionConstants):

        self.constants = constants

        self.threshold = constants.DEFAULT_THRESHOLD



        # This is the final, curated list of patterns.
        # They are ordered from most specific/extreme to most general.
        self.cleaning_patterns = [
            # 1. Targets extreme phrase repetition with separators (e.g., "あ!!あ!!あ!!")
            # Increased phrase length limit from {1,8} to {1,30} for long Japanese phrases (#209)
            ('phrase_with_separator', regex.compile(r'((?:[\p{L}\p{N}]{1,30}[、,!\s!!??。。・〜ー]+))\1{3,}'), r'\1'),

            # 2. Targets extreme multi-character word repetition (e.g., "ハッハッハッハッ")
            ('multi_char_word', regex.compile(r'(([ぁ-んァ-ン]{2,4}))\1{3,}'), r'\1\1'),

            # 3. Targets phrase repetition with a comma (e.g., "ゆーちゃん、ゆーちゃん、ゆーちゃん")
            # Increased phrase length limit from {1,10} to {1,30} (#209)
            ('phrase_with_comma', regex.compile(r'((?:[\p{L}\p{N}]{1,30}[、,]\s*))\1{2,}'), r'\1'),

            # 3b. Targets newline/whitespace separated single-character floods (e.g., "あ\nあ\nあ")
            ('single_char_whitespace_flood', regex.compile(r'([ぁ-んァ-ン])(?:[\s　]*\1){3,}'), r'\1\1'),

            # 4. Targets single character with prefix (e.g., "あらららら...")
            ('prefix_plus_char', regex.compile(r'([ぁ-んァ-ン]{1,2})([ぁ-んァ-ン])\2{3,}'), r'\1\2\2'),

            # 5. Targets simple single-character floods (e.g., "ううううう")
            # Now includes optional dakuten/handakuten marks — both combining (U+3099, U+309A)
            # and standalone (U+309B, U+309C) forms — so that "あ゛あ゛あ゛あ゛" is matched (#209)
            ('single_char_flood', regex.compile(r'([ぁ-んァ-ン][゙゚゛゜]?)\1{3,}'), r'\1\1'),

            # 6. Targets vowel extensions (e.g., "あ〜〜〜〜")
            ('vowel_extension', regex.compile(r'([ぁ-んァ-ン])([〜ー])\2{3,}'), r'\1\2\2'),

            # 7. Targets wave-dash + comma phrase repetitions (e.g., "あ〜、あ〜、あ〜、") (#209)
            ('wavedash_comma_phrase', regex.compile(r'([\p{L}]{1,10}[〜ー]+[、,]\s*)\1{2,}'), r'\1'),
        ]



        logger.debug(f"RepetitionCleaner initialized with {len(self.cleaning_patterns)} final cleaning patterns.")



    def clean_repetitions(self, text: str) -> Tuple[str, List[Dict]]:
        """
        Applies cleaning in 3 layers:
        1. Curated regex patterns (specific known repetition types)
        2. Generic substring repetition detector (safety net for unknown patterns)
        3. Absolute length limit (hallucination catch-all)
        """
        if not text or not text.strip():
            return text, []

        modifications = []
        current_text = text

        # === Layer 1: Curated regex patterns ===
        for name, pattern, replacement in self.cleaning_patterns:
            try:
                original_text = current_text
                new_text = pattern.sub(replacement, original_text)

                if new_text != original_text:
                    modifications.append({
                        'type': name,
                        'pattern': pattern.pattern,
                        'original': original_text,
                        'modified': new_text,
                        'confidence': 0.99,
                        'category': 'repetition_cleaning'
                    })
                    current_text = new_text
            except Exception as e:
                logger.warning(f"Pattern '{name}' failed on text '{text[:30]}...': {e}")
                continue

        # === Layer 2: Generic substring repetition detector (safety net) ===
        # If text is still long after Layer 1, check for ANY repeated substring
        # that dominates the text. This catches patterns the regex list missed. (#209)
        if len(current_text) > 40:
            cleaned, was_cleaned = self._detect_generic_repetition(current_text)
            if was_cleaned:
                modifications.append({
                    'type': 'generic_repetition_safety_net',
                    'pattern': 'substring_dominance_detector',
                    'original': current_text,
                    'modified': cleaned,
                    'confidence': 0.95,
                    'category': 'repetition_cleaning'
                })
                current_text = cleaned

        # === Layer 3: Absolute length limit ===
        # Normal Japanese subtitles are 10-40 chars. Lines exceeding the max are
        # almost certainly Whisper repetition hallucinations. (#209)
        max_len = self.constants.MAX_SUBTITLE_TEXT_LENGTH
        if len(current_text) > max_len:
            # Try to break at the last comma or period, but never truncate below
            # 75% of max_len to avoid over-cutting when the boundary is early.
            floor = int(max_len * 0.75)
            truncated = current_text[:max_len]
            for sep in ('。', '、'):
                if sep in truncated:
                    candidate = truncated.rsplit(sep, 1)[0]
                    if len(candidate) >= floor:
                        truncated = candidate
                        break
            logger.warning(
                f"Subtitle exceeds {max_len} chars ({len(current_text)} chars), "
                f"likely hallucination. Truncating."
            )
            modifications.append({
                'type': 'length_limit_truncation',
                'pattern': f'len>{max_len}',
                'original': current_text,
                'modified': truncated,
                'confidence': 0.90,
                'category': 'repetition_cleaning'
            })
            current_text = truncated

        return current_text.strip(), modifications

    def _detect_generic_repetition(self, text: str) -> Tuple[str, bool]:
        """
        Generic substring repetition detector.

        Finds any substring of length 2-50, starting at ANY position in the text,
        that repeats enough times to cover >50% of the text. If found, reduces
        to 1-2 occurrences.

        This is the safety net for patterns the curated regex list doesn't cover.
        Algorithm: For each substring length, try candidates starting at each
        position in the text. To keep it tractable, we limit candidate start
        positions to the first `sub_len` characters (any repeating unit must
        begin within its own length from the start).
        """
        text_len = len(text)
        coverage_threshold = self.constants.GENERIC_REPETITION_COVERAGE_THRESHOLD
        min_occurrences = self.constants.GENERIC_REPETITION_MIN_OCCURRENCES
        best_sub = None
        best_count = 0
        best_coverage = 0.0

        # Try substring lengths from 2 to min(50, text_len // 2)
        max_sub_len = min(50, text_len // 2)
        for sub_len in range(2, max_sub_len + 1):
            # Try candidates starting at each offset within one unit length.
            # A repeating unit "ABCABC..." must start within positions 0..sub_len-1.
            # For text like "XYお腹お腹お腹", the unit "お腹" starts at position 2,
            # which is within sub_len=2 from the start.
            for start in range(min(sub_len, text_len - sub_len + 1)):
                candidate = text[start:start + sub_len]
                count = 0
                pos = 0
                while pos <= text_len - sub_len:
                    if text[pos:pos + sub_len] == candidate:
                        count += 1
                        pos += sub_len
                    else:
                        pos += 1

                if count >= min_occurrences:
                    coverage = (count * sub_len) / text_len
                    if coverage > best_coverage:
                        best_coverage = coverage
                        best_count = count
                        best_sub = candidate

        if best_sub and best_coverage >= coverage_threshold:
            # Reduce to 1-2 occurrences
            keep = 2 if len(best_sub) <= 5 else 1
            cleaned = (best_sub * keep).strip()
            logger.debug(
                f"Generic repetition detected: '{best_sub[:20]}...' x{best_count} "
                f"(coverage {best_coverage:.0%}). Reduced to {keep} occurrence(s)."
            )
            return cleaned, True

        return text, False







    def _is_all_repetition(self, text: str) -> bool:

        """

        Check if text consists almost entirely of repetitive patterns.

        This is now more robust to handle the various long-line examples.

        """

        # More than 90% of the string is a single character (ignoring punctuation)

        stripped_text = regex.sub(r'[\p{P}\p{Z}]', '', text)

        if len(stripped_text) > 10:

            most_common_char_count = Counter(stripped_text).most_common(1)[0][1]

            if most_common_char_count / len(stripped_text) > 0.9:

                return True

        

        # Check for long sequences of a short phrase + separator (e.g., "あ、あ、あ、")

        if regex.match(r'^((?:.{1,5}?)[、,!\s!?・]){5,}$', text):

            return True

            

        # Check for long sequences of a short multi-char word (e.g., "ハッハッハッ")

        if regex.match(r'^((?:.{2,5}?))\1{3,}$', text):

            return True



        # Check for long vowel extensions

        if regex.match(r'^[ぁ-んァ-ン][〜ー]{10,}$', text):

            return True

            

        return False





    def _is_all_repetition(self, text: str) -> bool:

        """Check if text consists only of repetitive patterns"""

        # Check for long sequences of repeated characters



        '''



        if regex.match(r'^([ぁ-んァ-ン])\1{20,}$', text):

            return True

            

        # Check for long sequences with separators

        if regex.match('^([ぁ-んァ-ン][、,!！?？]\\s*){10,}$', text):

            return True

            

        # Check for long vowel extensions

        if regex.match(r'^[ぁ-んァ-ン][〜ー]{20,}$', text):

            return True

            

        return False



        '''



        return True



    def _validate_modification(self, original: str, modified: str) -> bool:

        """

        Validates that a modification is reasonable before accepting it.

        Prevents aggressive patterns from destroying valid text.

        """

        # Allow complete removal if the original was identified as all repetition

        '''



        if not modified.strip() and self._is_all_repetition(original):

            return True

            

        # A basic sanity check to prevent erasing content

        if not modified or not modified.strip():

            logger.warning("VALIDATION FAILED: Modified text is empty")

            return False

            

        # Allow a significant reduction in length only if the original was all repetition

        if len(modified) < len(original) * 0.05:  # e.g., less than 5% of original length

            if self._is_all_repetition(original):

                return True

            logger.warning(f"VALIDATION FAILED: Modified text too short (possible over-reduction)")

            return False

        '''

            

        return True



    def _is_protected_content_enhanced(self, text: str) -> bool:

        stripped = text.strip()

        

        '''

        if stripped in self.constants.LEGITIMATE_REPETITIONS:

            return True

        if len(stripped) <= 3:

            return True

        for pattern in self.protected_patterns:

            if pattern.search(text):

                return True



        # Force-clean override for ultra-long lines with only kana

        if len(stripped) > 45:

            has_kanji = bool(regex.search('\\p{Han}', text))

            has_latin = bool(regex.search(r'[a-zA-Z]', text))

            if not has_kanji and not has_latin:

                logger.debug("Bypassing protection: very long line without kanji or Latin.")

                return False  # force-clean it



        # Mixed script = likely real content

        has_hira = bool(regex.search('\\p{Hiragana}', text))

        has_kata = bool(regex.search('\\p{Katakana}', text))

        has_kanji = bool(regex.search('\\p{Han}', text))

        has_latin = bool(regex.search(r'[a-zA-Z]', text))



        script_count = sum([has_hira, has_kata, has_kanji, has_latin])

        if script_count >= 2:

            return True

        '''

        return False





    def _clean_high_density_repetitions_safe(self, text: str) -> Tuple[str, List[Dict]]:

        """

        Simplified high-density cleaning.

        """

        if len(text) < self.constants.HIGH_DENSITY_MIN_LENGTH:

            return text, []



        modifications = []

        

        try:

            words = regex.findall('\\p{L}+', text)

            if not words or len(words) < self.constants.HIGH_DENSITY_MIN_OCCURRENCES:

                return text, []



            word_counts = Counter(words)

            most_common_word, count = word_counts.most_common(1)[0]



            if (count > self.constants.HIGH_DENSITY_MIN_OCCURRENCES and

                count / len(words) > self.constants.HIGH_DENSITY_RATIO and

                len(most_common_word) > 1):



                parts = text.split()

                kept_count = 0

                new_parts = []

                

                for part in parts:

                    if most_common_word in part and kept_count >= self.threshold:

                        continue

                    else:

                        new_parts.append(part)

                        if most_common_word in part:

                            kept_count += 1



                modified_text = ' '.join(new_parts).strip()



                if text != modified_text and len(modified_text) > 0:

                    modifications.append({

                        'type': 'high_density_repetition',

                        'pattern': 'high_density_detection',

                        'original': text,

                        'modified': modified_text,

                        'confidence': 0.90,

                        'repeated_word': most_common_word,

                        'repetition_count': count

                    })

                    return modified_text, modifications



        except Exception as e:

            logger.warning(f"High-density repetition cleaning failed: {e}")

            return text, []



        return text, modifications







    def _clean_character_repetitions(self, text: str) -> Tuple[str, List[Dict]]:

        """Clean character repetitions based on a defined constant."""

        modifications = []

        

        def replacer(match):

            char = match.group(1)

            return char * self.threshold



        original_text = text

        

        # This now uses the new, descriptive constant from the constants file.

        # The quantifier for N or more items is {N-1,}.

        quantifier = self.constants.MIN_CHAR_REPETITION_THRESHOLD - 1

        pattern_str = self.constants.CHAR_REPETITION_PATTERN + f'\\1{{{quantifier},}}'

        char_repeat_pattern = regex.compile(pattern_str)



        try:

            modified_text = char_repeat_pattern.sub(replacer, text)



            if original_text != modified_text:

                if self._validate_modification(original_text, modified_text):

                    modifications.append({

                        'type': 'character_repetition_reduction',

                        'original': original_text,

                        'modified': modified_text,

                        'confidence': 0.95,

                        'category': 'character_repetition'

                    })

                else:

                    # Revert if validation fails

                    modified_text = original_text

            

            return modified_text, modifications

        except Exception as e:

            logger.warning(f"Character repetition cleaning failed with error: {e}")

            return text, []



    def _pre_process_special_patterns(self, text: str) -> Tuple[str, List[Dict]]:

        """Handle special repetitive patterns using defined constants."""

        modifications = []

        current_text = text



        # The quantifiers are now based on the new, descriptive constants

        vowel_quantifier = self.threshold + 2

        phrase_quantifier = self.constants.MIN_PHRASE_REPETITION_THRESHOLD - 1



        patterns_to_apply = [

            ('vowel_extension', regex.compile(self.constants.VOWEL_EXTENSION_PATTERN + f'{{{vowel_quantifier},}}'), lambda m: m.group(1) + m.group(2) * self.threshold),

            

            # --- THIS IS THE LINE TO CHANGE FOR CONSERVATIVE CLEANING ---

            ('comma_phrase', regex.compile(self.constants.COMMA_PHRASE_PATTERN + r'\1' + f'{{{phrase_quantifier},}}'), lambda m: m.group(1) * self.threshold),

            # -----------------------------------------------------------



            ('prefix_char_flood', regex.compile(self.constants.PREFIX_PLUS_CHAR_FLOOD_PATTERN), lambda m: m.group(1) + m.group(2) * self.threshold),

            ('small_vowel_flood', regex.compile(self.constants.SMALL_VOWEL_FLOOD_PATTERN), lambda m: m.group(1) + m.group(2) * self.threshold),

        ]





        for name, pattern, replacement in patterns_to_apply:

            try:

                original_text = current_text

                

                new_text = original_text

                while True:

                    processed_text = pattern.sub(replacement, new_text)

                    if processed_text == new_text:

                        break

                    new_text = processed_text



                if original_text != new_text:

                    if self._validate_modification(original_text, new_text):

                        modifications.append({

                            'type': name,

                            'pattern': pattern.pattern,

                            'original': original_text,

                            'modified': new_text,

                            'confidence': 0.98,

                            'category': 'repetition_special'

                        })

                        current_text = new_text

                    else:

                        current_text = original_text

                        logger.warning(f"Validation failed for special pattern '{name}', reverting.")

                    

            except Exception as e:

                logger.warning(f"Special pattern '{name}' failed: {e}")

                continue



        return current_text, modifications



            



    def _clean_word_repetitions(self, text: str) -> Tuple[str, List[Dict]]:

        """Clean word repetitions without punctuation: e.g., 'dame dame dame' -> 'dame dame'"""

        modifications = []

        pattern_str = r'\b(\p{L}{2,})\b(?:\s+\1){' + str(self.threshold) + r',}'

        word_pattern = regex.compile(pattern_str)



        def replacer(match):

            word = match.group(1)

            return ' '.join([word] * self.threshold)



        original_text = text

        modified_text = word_pattern.sub(replacer, original_text)



        if original_text != modified_text:

             modifications.append({

                'type': 'word_repetition_reduction',

                'original': original_text,

                'modified': modified_text,

                'confidence': 0.95,

                'category': 'word_repetition'

            })



        return modified_text, modifications

