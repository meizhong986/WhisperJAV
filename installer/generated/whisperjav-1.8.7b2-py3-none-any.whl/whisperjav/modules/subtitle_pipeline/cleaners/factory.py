"""
TextCleaner factory with lazy-import backend registry.

Follows the same factory pattern as SpeechSegmenterFactory — backends
are loaded on demand to avoid importing heavy dependencies at startup.
"""

import importlib
from typing import Any

from whisperjav.modules.subtitle_pipeline.protocols import TextCleaner

# Registry: name → "module.path.ClassName"
_REGISTRY: dict[str, str] = {
    "qwen3": "whisperjav.modules.subtitle_pipeline.cleaners.qwen3.Qwen3TextCleaner",
    "passthrough": "whisperjav.modules.subtitle_pipeline.cleaners.passthrough.PassthroughCleaner",
    "anime-whisper": "whisperjav.modules.subtitle_pipeline.cleaners.anime_whisper.AnimeWhisperCleaner",
}

# Cache for loaded classes
_CLASS_CACHE: dict[str, type] = {}


class TextCleanerFactory:
    """Factory for creating TextCleaner instances."""

    @classmethod
    def create(cls, name: str, **kwargs: Any) -> TextCleaner:
        """
        Create a TextCleaner by backend name.

        Args:
            name: Backend name (e.g., "qwen3", "passthrough").
            **kwargs: Passed to the backend constructor.

        Returns:
            A TextCleaner instance.

        Raises:
            ValueError: If the backend name is unknown.
            ImportError: If the backend's dependencies are not installed.
        """
        backend_class = cls._load_class(name)
        return backend_class(**kwargs)

    @classmethod
    def available(cls) -> list[str]:
        """Return list of registered backend names."""
        return list(_REGISTRY.keys())

    @classmethod
    def _load_class(cls, name: str) -> type:
        """Lazy-load and cache a backend class."""
        if name in _CLASS_CACHE:
            return _CLASS_CACHE[name]

        if name not in _REGISTRY:
            raise ValueError(f"Unknown text cleaner: '{name}'. Available: {cls.available()}")

        module_path = _REGISTRY[name]
        module_name, class_name = module_path.rsplit(".", 1)

        try:
            module = importlib.import_module(module_name)
            backend_class = getattr(module, class_name)
        except (ImportError, AttributeError) as e:
            raise ImportError(f"Failed to load text cleaner '{name}' from {module_path}: {e}") from e

        _CLASS_CACHE[name] = backend_class
        return backend_class
