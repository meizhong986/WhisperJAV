"""Ensemble Orchestrator for two-pass pipeline processing."""

import json
import multiprocessing as mp
import pickle
import shutil
import time
# ProcessPoolExecutor removed - using raw mp.Process with Drop-Box pattern
# from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from whisperjav.utils.logger import logger
from whisperjav.utils.metadata_manager import MetadataManager
from whisperjav.utils.parameter_tracer import NullTracer

from .merge import MergeEngine
from .pass_worker import WorkerPayload, run_pass_worker
from .utils import resolve_language_code


class EnsembleOrchestrator:
    """Orchestrates two-pass ensemble processing with result merging."""

    def __init__(
        self,
        output_dir: str,
        temp_dir: str,
        keep_temp_files: bool = False,
        subs_language: str = 'native',
        progress_display=None,
        log_level: str = "INFO",
        serial_file_processing: bool = False,
        **kwargs
    ):
        """
        Initialize the ensemble orchestrator.

        Args:
            output_dir: Output directory for final results
            temp_dir: Temporary directory for processing
            keep_temp_files: Whether to keep intermediate files
            subs_language: Language for subtitles ('native' or 'direct-to-english')
            progress_display: Progress display object
            log_level: Log level to propagate to subprocess workers
            serial_file_processing: If True, each file completes its full cycle
                (Pass 1 → Pass 2 → Merge) before the next file begins. Slower
                (reloads models per file) but delivers results incrementally.
            **kwargs: Additional parameters passed to pipelines
        """
        # "source" sentinel means each file's SRT goes next to its input file
        self.source_output_mode = (
            isinstance(output_dir, str) and output_dir.lower().strip() == "source"
        )
        if self.source_output_mode:
            # In source mode, there's no single output dir — per-file dirs are resolved later.
            # Use temp_dir as the fallback for metadata/summary files.
            self.output_dir = Path(temp_dir)
        else:
            self.output_dir = Path(output_dir)
            self.output_dir.mkdir(parents=True, exist_ok=True)

        self.temp_dir = Path(temp_dir)
        self.keep_temp_files = keep_temp_files
        self.subs_language = subs_language
        self.progress_display = progress_display
        self.log_level = log_level
        self.serial_file_processing = serial_file_processing
        self.extra_kwargs = kwargs
        self.worker_kwargs = self._filter_picklable_kwargs(kwargs)

        self.temp_dir.mkdir(parents=True, exist_ok=True)

        self.metadata_manager = MetadataManager(self.temp_dir, self.output_dir)
        self.merge_engine = MergeEngine()

        # Extract parameter tracer for orchestrator-level tracing
        # Note: Cannot pass to subprocesses (not picklable), so trace at orchestrator level only
        self.tracer = kwargs.get('parameter_tracer', NullTracer())

    def process(
        self,
        media_info: Dict,
        pass1_config: Dict[str, Any],
        pass2_config: Optional[Dict[str, Any]] = None,
        merge_strategy: str = 'pass1_primary'
    ) -> Dict:
        """Process a single file by delegating to batch processing."""
        results = self.process_batch(
            media_files=[media_info],
            pass1_config=pass1_config,
            pass2_config=pass2_config,
            merge_strategy=merge_strategy,
        )
        if not results:
            raise RuntimeError("Ensemble processing produced no results")
        return results[0]

    def process_batch(
        self,
        media_files: List[Dict],
        pass1_config: Dict[str, Any],
        pass2_config: Optional[Dict[str, Any]] = None,
        merge_strategy: str = 'pass1_primary'
    ) -> List[Dict]:
        if not media_files:
            return []

        # Serial mode: each file completes Pass1→Pass2→Merge before the next starts.
        # Single-file batches always take the batch path (identical result, no overhead).
        if self.serial_file_processing and len(media_files) > 1:
            return self._process_batch_serial(
                media_files, pass1_config, pass2_config, merge_strategy,
            )

        batch_start = time.time()
        serialized_media = self._serialize_media_files(media_files)

        # Annotate each file with its resolved output directory.
        # In source mode, each file's SRT goes next to its input file.
        for info in serialized_media:
            info['output_dir'] = str(self._resolve_file_output_dir(info))

        pass_languages = {
            1: resolve_language_code(pass1_config, self.subs_language),
        }
        if pass2_config:
            pass_languages[2] = resolve_language_code(pass2_config, self.subs_language)

        # Trace ensemble configuration
        self.tracer.emit("ensemble_batch_start", {
            "files_count": len(serialized_media),
            "pass1_pipeline": pass1_config.get('pipeline'),
            "pass2_pipeline": pass2_config.get('pipeline') if pass2_config else None,
            "merge_strategy": merge_strategy,
            "subs_language": self.subs_language,
        })

        logger.info(
            "Starting batch ensemble processing for %s files (Pass 1: %s)",
            len(serialized_media),
            pass1_config['pipeline'],
        )

        # Trace pass 1 start
        self.tracer.emit("ensemble_pass_start", {
            "pass_number": 1,
            "pipeline": pass1_config.get('pipeline'),
            "config": pass1_config,
        })

        logger.debug(
            "Starting Pass 1 for %d files with pipeline=%s, sensitivity=%s",
            len(serialized_media),
            pass1_config.get('pipeline'), pass1_config.get('sensitivity')
        )

        pass1_results = self._run_pass_in_subprocess(
            pass_number=1,
            media_files=serialized_media,
            pass_config=pass1_config,
            language_code=pass_languages[1],
        )

        # Trace pass 1 complete
        pass1_completed = sum(1 for r in pass1_results.values() if r.get('status') == 'completed')
        pass1_failed = sum(1 for r in pass1_results.values() if r.get('status') == 'failed')
        pass1_subs = sum(r.get('subtitles', 0) for r in pass1_results.values() if r.get('status') == 'completed')

        logger.debug(
            "Pass 1 results: %d completed, %d failed, basenames=%s",
            pass1_completed, pass1_failed, list(pass1_results.keys())
        )

        self.tracer.emit("ensemble_pass_complete", {
            "pass_number": 1,
            "results_count": len(pass1_results),
            "completed": pass1_completed,
            "failed": pass1_failed,
        })

        # Log pass 1 completion for user feedback
        logger.info(
            "Pass 1 completed: %d/%d file(s) successful, %d subtitles total",
            pass1_completed, len(pass1_results), pass1_subs
        )

        pass2_results: Dict[str, Dict[str, Any]] = {}
        if pass2_config:
            logger.info(
                "Pass 2 is enabled (%s). Launching worker...",
                pass2_config['pipeline'],
            )

            # Trace pass 2 start
            self.tracer.emit("ensemble_pass_start", {
                "pass_number": 2,
                "pipeline": pass2_config.get('pipeline'),
                "config": pass2_config,
            })

            logger.debug(
                "Starting Pass 2 for %d files with pipeline=%s, sensitivity=%s",
                len(serialized_media),
                pass2_config.get('pipeline'), pass2_config.get('sensitivity')
            )

            pass2_results = self._run_pass_in_subprocess(
                pass_number=2,
                media_files=serialized_media,
                pass_config=pass2_config,
                language_code=pass_languages[2],
            )

            # Trace pass 2 complete
            pass2_completed = sum(1 for r in pass2_results.values() if r.get('status') == 'completed')
            pass2_failed = sum(1 for r in pass2_results.values() if r.get('status') == 'failed')
            pass2_subs = sum(r.get('subtitles', 0) for r in pass2_results.values() if r.get('status') == 'completed')

            logger.debug(
                "Pass 2 results: %d completed, %d failed, basenames=%s",
                pass2_completed, pass2_failed, list(pass2_results.keys())
            )

            self.tracer.emit("ensemble_pass_complete", {
                "pass_number": 2,
                "results_count": len(pass2_results),
                "completed": pass2_completed,
                "failed": pass2_failed,
            })

            # Log pass 2 completion for user feedback
            logger.info(
                "Pass 2 completed: %d/%d file(s) successful, %d subtitles total",
                pass2_completed, len(pass2_results), pass2_subs
            )

        all_metadata: List[Dict[str, Any]] = []
        table_rows: List[Dict[str, str]] = []

        for media_info in serialized_media:
            metadata, row = self._process_single_file_merge(
                media_info, pass1_results, pass2_results,
                pass1_config, pass2_config, merge_strategy, pass_languages,
            )
            all_metadata.append(metadata)
            table_rows.append(row)

        if not self.keep_temp_files:
            for media_info in serialized_media:
                self._cleanup_intermediate(media_info['basename'])

        self._print_summary_table(table_rows, time.time() - batch_start)
        summary_path = self._write_batch_summary(all_metadata)
        if summary_path:
            logger.info("Batch summary saved to %s", summary_path)

        # Trace batch completion
        batch_duration = time.time() - batch_start
        completed_count = sum(1 for m in all_metadata if m.get('status') == 'completed')
        self.tracer.emit("ensemble_batch_complete", {
            "files_processed": len(all_metadata),
            "completed": completed_count,
            "failed": len(all_metadata) - completed_count,
            "total_duration_seconds": round(batch_duration, 2),
            "summary_path": str(summary_path) if summary_path else None,
        })

        return all_metadata

    def _process_single_file_merge(
        self,
        media_info: Dict[str, Any],
        pass1_results: Dict[str, Dict],
        pass2_results: Dict[str, Dict],
        pass1_config: Dict[str, Any],
        pass2_config: Optional[Dict[str, Any]],
        merge_strategy: str,
        pass_languages: Dict[int, str],
    ) -> tuple:
        """Merge results for a single file and produce metadata + display row.

        This is the shared merge/metadata logic used by both batch and serial modes.

        Returns:
            (ensemble_metadata, row_display) tuple.
        """
        basename = media_info['basename']
        lang_code = pass_languages[1]
        ensemble_metadata = self._create_ensemble_metadata(
            media_info, pass1_config, pass2_config, merge_strategy
        )

        pass1 = pass1_results.get(basename)
        pass2 = pass2_results.get(basename) if pass2_config else None

        row_display = {
            'file': basename,
            'pass1': self._format_status(pass1),
            'pass2': self._format_status(pass2) if pass2_config else 'n/a',
            'merge': 'n/a' if not pass2_config else 'NOK',
            'final': f"{basename}: missing",
        }

        if not pass1 or pass1['status'] != 'completed':
            error_msg = pass1.get('error') if pass1 else 'Pass 1 worker returned no result'
            ensemble_metadata['pass1'] = {'status': 'failed', 'error': error_msg}
            if pass2_config:
                ensemble_metadata['pass2'] = (
                    pass2 if pass2 else {'status': 'skipped', 'error': 'Pass 2 not executed'}
                )
            else:
                ensemble_metadata['pass2'] = {'status': 'skipped'}
            ensemble_metadata['status'] = 'failed'
            ensemble_metadata['merge'] = {'status': 'skipped'}
            return ensemble_metadata, row_display

        pass1_srt = Path(pass1['srt_path']) if pass1.get('srt_path') else None

        # Defensive check: verify pass1 SRT file actually exists
        if pass1_srt and not pass1_srt.exists():
            logger.warning(
                "Pass 1 reported completed but SRT file not found: %s",
                pass1_srt,
            )
            pass1_srt = None  # Treat as if no SRT was produced

        ensemble_metadata['pass1'] = {
            'status': pass1['status'],
            'srt_path': str(pass1_srt) if pass1_srt else None,
            'subtitles': pass1.get('subtitles', 0),
            'processing_time': pass1.get('processing_time', 0.0),
        }

        final_output_path: Optional[Path] = None
        merge_info: Dict[str, Any] = {'status': 'skipped' if not pass2_config else 'pending'}

        if pass2_config:
            if pass2 and pass2['status'] == 'completed' and pass2.get('srt_path'):
                pass2_srt = Path(pass2['srt_path'])

                # Defensive check: verify pass2 SRT file actually exists
                if not pass2_srt.exists():
                    logger.warning(
                        "Pass 2 reported completed but SRT file not found: %s",
                        pass2_srt,
                    )
                    # Treat pass2 as failed
                    ensemble_metadata['pass2'] = {
                        'status': 'failed',
                        'error': f'SRT file not found: {pass2_srt}',
                        'processing_time': pass2.get('processing_time', 0.0),
                    }
                    merge_info = {'status': 'skipped', 'reason': 'pass2_file_missing'}
                    row_display['merge'] = 'NOK'
                    row_display['pass2'] = 'NOK'
                    if pass1_srt:
                        final_output_path = pass1_srt
                        row_display['final'] = f"fallback to pass1 ({pass1_srt.name})"
                else:
                    # pass2_srt exists - record pass2 metadata
                    ensemble_metadata['pass2'] = {
                        'status': pass2['status'],
                        'srt_path': pass2['srt_path'],
                        'subtitles': pass2.get('subtitles', 0),
                        'processing_time': pass2.get('processing_time', 0.0),
                    }

                    # Check if pass1_srt is valid before attempting merge
                    if not pass1_srt:
                        logger.warning(
                            "Cannot merge: Pass 1 SRT file missing or invalid for %s",
                            basename,
                        )
                        merge_info = {'status': 'skipped', 'reason': 'pass1_file_missing'}
                        row_display['merge'] = 'NOK'
                        # Use pass2 as final output since pass1 is unavailable
                        final_output_path = pass2_srt
                        row_display['final'] = f"pass2 only ({pass2_srt.name})"
                    else:
                        # Both pass1 and pass2 SRT files exist - proceed with merge
                        tmp_merge = self.temp_dir / f"{basename}.merge.tmp.srt"
                        tmp_merge.parent.mkdir(parents=True, exist_ok=True)
                        file_output_dir = Path(media_info.get('output_dir', str(self.output_dir)))
                        final_candidate = file_output_dir / f"{basename}.{lang_code}.merged.whisperjav.srt"
                        try:
                            merge_stats = self.merge_engine.merge(
                                srt1_path=pass1_srt,
                                srt2_path=pass2_srt,
                                output_path=tmp_merge,
                                strategy=merge_strategy,
                            )
                            if final_candidate.exists():
                                final_candidate.unlink()
                            shutil.move(tmp_merge, final_candidate)
                            merge_info = {
                                'status': 'completed',
                                'strategy': merge_strategy,
                                'output_path': str(final_candidate),
                                'statistics': merge_stats,
                            }
                            final_output_path = final_candidate
                            row_display['merge'] = 'OK'
                            row_display['final'] = final_candidate.name
                        except Exception as merge_error:
                            if tmp_merge.exists():
                                tmp_merge.unlink()
                            logger.error("Merge failed for %s: %s", basename, merge_error)
                            merge_info = {'status': 'failed', 'error': str(merge_error)}
                            row_display['merge'] = 'NOK'
                            if pass1_srt:
                                final_output_path = pass1_srt
                                row_display['final'] = f"fallback to pass1 ({pass1_srt.name})"
            else:
                ensemble_metadata['pass2'] = (
                    {'status': pass2['status'], 'error': pass2.get('error')}
                    if pass2
                    else {'status': 'failed', 'error': 'Pass 2 did not return a result'}
                )
                merge_info = {'status': 'skipped', 'reason': 'pass2_failed'}
                row_display['merge'] = 'NOK'
                row_display['pass2'] = self._format_status(ensemble_metadata['pass2'])
                if pass1_srt:
                    final_output_path = pass1_srt
                    row_display['final'] = f"fallback to pass1 ({pass1_srt.name})"
        else:
            ensemble_metadata['pass2'] = {'status': 'skipped'}

        if not pass2_config and pass1_srt:
            final_output_path = pass1_srt
            row_display['final'] = pass1_srt.name

        ensemble_metadata['merge'] = merge_info

        passes_completed = 2 if pass2_config and pass2 and pass2.get('status') == 'completed' else 1
        total_time = pass1.get('processing_time', 0.0) + (pass2.get('processing_time', 0.0) if pass2 else 0.0)
        ensemble_metadata['summary'] = {
            'final_output': str(final_output_path) if final_output_path else None,
            'passes_completed': passes_completed,
            'total_processing_time_seconds': total_time,
        }
        ensemble_metadata['output_files'] = {
            'final_srt': str(final_output_path) if final_output_path else None,
            'pass1_srt': pass1.get('srt_path'),
            'pass2_srt': pass2.get('srt_path') if pass2 else None,
        }

        ensemble_metadata.setdefault('status', 'completed')

        return ensemble_metadata, row_display

    def _process_batch_serial(
        self,
        media_files: List[Dict],
        pass1_config: Dict[str, Any],
        pass2_config: Optional[Dict[str, Any]],
        merge_strategy: str,
    ) -> List[Dict]:
        """Process files serially: each file completes Pass1→Pass2→Merge before the next starts.

        Slower than batch mode (reloads models per file) but delivers results incrementally —
        each file's final SRT is on disk and usable before the next file begins processing.
        """
        batch_start = time.time()
        serialized_media = self._serialize_media_files(media_files)

        for info in serialized_media:
            info['output_dir'] = str(self._resolve_file_output_dir(info))

        pass_languages = {
            1: resolve_language_code(pass1_config, self.subs_language),
        }
        if pass2_config:
            pass_languages[2] = resolve_language_code(pass2_config, self.subs_language)

        # Trace serial ensemble start
        self.tracer.emit("ensemble_batch_start", {
            "files_count": len(serialized_media),
            "pass1_pipeline": pass1_config.get('pipeline'),
            "pass2_pipeline": pass2_config.get('pipeline') if pass2_config else None,
            "merge_strategy": merge_strategy,
            "subs_language": self.subs_language,
            "serial_mode": True,
        })

        total_files = len(serialized_media)
        logger.info(
            "Starting SERIAL ensemble: %d files (each file completes fully before next)",
            total_files,
        )

        all_metadata: List[Dict[str, Any]] = []
        table_rows: List[Dict[str, str]] = []

        for file_idx, media_info in enumerate(serialized_media, 1):
            basename = media_info['basename']
            file_start = time.time()

            # --- Pass 1 ---
            logger.info(
                "[%d/%d] %s — Pass 1 (%s)...",
                file_idx, total_files, basename, pass1_config['pipeline'],
            )
            pass1_results = self._run_pass_in_subprocess(
                pass_number=1,
                media_files=[media_info],
                pass_config=pass1_config,
                language_code=pass_languages[1],
            )

            # --- Pass 2 (if enabled) ---
            pass2_results: Dict[str, Dict[str, Any]] = {}
            if pass2_config:
                logger.info(
                    "[%d/%d] %s — Pass 2 (%s)...",
                    file_idx, total_files, basename, pass2_config['pipeline'],
                )
                pass2_results = self._run_pass_in_subprocess(
                    pass_number=2,
                    media_files=[media_info],
                    pass_config=pass2_config,
                    language_code=pass_languages[2],
                )

            # --- Merge + metadata (reuses shared method) ---
            if pass2_config:
                logger.info(
                    "[%d/%d] %s — Merge (%s)...",
                    file_idx, total_files, basename, merge_strategy,
                )
            metadata, row = self._process_single_file_merge(
                media_info, pass1_results, pass2_results,
                pass1_config, pass2_config, merge_strategy, pass_languages,
            )
            all_metadata.append(metadata)
            table_rows.append(row)

            # --- Per-file cleanup ---
            if not self.keep_temp_files:
                self._cleanup_intermediate(basename)

            # --- Per-file completion banner ---
            file_elapsed = time.time() - file_start
            final_output = metadata.get('summary', {}).get('final_output')
            if final_output and metadata.get('status') != 'failed':
                final_name = Path(final_output).name
                subs_count = metadata.get('pass1', {}).get('subtitles', '?')
                logger.info(
                    "[%d/%d] DONE: %s -> %s (%s subs, %.0fs)",
                    file_idx, total_files, basename, final_name,
                    subs_count, file_elapsed,
                )
            else:
                logger.warning(
                    "[%d/%d] FAILED: %s (%.0fs)",
                    file_idx, total_files, basename, file_elapsed,
                )

        # --- Batch summary (same as batch mode) ---
        self._print_summary_table(table_rows, time.time() - batch_start)
        summary_path = self._write_batch_summary(all_metadata)
        if summary_path:
            logger.info("Batch summary saved to %s", summary_path)

        batch_duration = time.time() - batch_start
        completed_count = sum(1 for m in all_metadata if m.get('status') == 'completed')
        self.tracer.emit("ensemble_batch_complete", {
            "files_processed": len(all_metadata),
            "completed": completed_count,
            "failed": len(all_metadata) - completed_count,
            "total_duration_seconds": round(batch_duration, 2),
            "summary_path": str(summary_path) if summary_path else None,
            "serial_mode": True,
        })

        return all_metadata

    def _run_pass_in_subprocess(
        self,
        pass_number: int,
        media_files: List[Dict[str, Any]],
        pass_config: Dict[str, Any],
        language_code: str,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Execute a pass inside an isolated worker process.

        Uses the "Drop-Box + Nuclear Exit" pattern:
        - Worker writes results to a pickle file (Drop-Box)
        - Worker exits via os._exit(0) to skip Python shutdown
        - Parent reads results from Drop-Box file

        This prevents ctranslate2 C++ destructor crashes on Windows.
        """
        import pickle

        # Get trace file path if tracer is active (ParameterTracer has output_path, NullTracer doesn't)
        trace_file_path = str(self.tracer.output_path) if hasattr(self.tracer, 'output_path') else None

        payload = WorkerPayload(
            pass_number=pass_number,
            media_files=media_files,
            pass_config=pass_config,
            output_dir=str(self.output_dir),
            temp_dir=str(self.temp_dir),
            keep_temp_files=self.keep_temp_files,
            subs_language=self.subs_language,
            extra_kwargs=self.worker_kwargs,
            language_code=language_code,
            log_level=self.log_level,
            trace_file_path=trace_file_path,
        )

        # Setup Drop-Box path (unique per pass)
        result_file = str(self.temp_dir / f"worker_result_pass{pass_number}.pkl")

        # Use 'spawn' start method for GPU compatibility across all platforms.
        # - Linux defaults to 'fork' which breaks CUDA/MPS in child processes
        #   (CUDA context cannot be re-initialized after fork)
        # - Windows and macOS ARM already use 'spawn' by default
        # - Explicitly setting 'spawn' ensures consistent, safe behavior everywhere
        # - Performance impact is negligible (<1% of total processing time)
        mp_context = mp.get_context('spawn')

        # Spawn "One-Shot" Process (not using ProcessPoolExecutor)
        # This gives us precise control over the lifecycle and avoids
        # pool poisoning when the worker calls os._exit(0)
        p = mp_context.Process(target=run_pass_worker, args=(payload, result_file))
        p.start()

        # Wait for process to die (Nuclear Exit or crash)
        p.join()

        # Analyze the aftermath
        if p.exitcode != 0:
            logger.error(
                "Pass %s worker died with exit code %s",
                pass_number, p.exitcode
            )

        # Read result from Drop-Box
        worker_output = None
        if Path(result_file).exists():
            try:
                with open(result_file, 'rb') as f:
                    worker_output = pickle.load(f)
                # Clean up Drop-Box file
                Path(result_file).unlink()
            except Exception as e:
                logger.error("Pass %s: Failed to read Drop-Box: %s", pass_number, e)

        # Handle missing or invalid Drop-Box
        if worker_output is None:
            logger.error("Pass %s: Worker produced no Drop-Box (crashed before writing?)", pass_number)
            return {
                info['basename']: {
                    'status': 'failed',
                    'error': f'Worker crash: exit code {p.exitcode}, no result file',
                }
                for info in media_files
            }

        worker_error = worker_output.get('worker_error')
        if worker_error:
            logger.error("Pass %s worker reported error:\n%s", pass_number, worker_error)

        results = worker_output.get('results') or []
        if not results:
            fallback_error = worker_error or 'Worker produced no results'
            return {
                info['basename']: {
                    'status': 'failed',
                    'error': fallback_error,
                }
                for info in media_files
            }

        formatted: Dict[str, Dict[str, Any]] = {}
        for item in results:
            formatted[item['basename']] = item

        # Ensure every media file has an entry even if the worker skipped it
        for info in media_files:
            basename = info['basename']
            if basename not in formatted:
                # Log when a file has no matching result - helps diagnose Unicode/encoding issues
                logger.warning(
                    "Pass %s: No result for basename (len=%d chars, %d UTF-8 bytes). "
                    "This may indicate a Unicode encoding mismatch between processes.",
                    pass_number,
                    len(basename),
                    len(basename.encode('utf-8')),
                )
                formatted[basename] = {
                    'status': 'failed',
                    'error': 'Worker returned no result for this file',
                }

        return formatted

    def _serialize_media_files(self, media_files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Convert media descriptors to picklable dicts before multiprocessing."""

        def normalize(value):
            if isinstance(value, Path):
                return str(value)
            if isinstance(value, dict):
                return {k: normalize(v) for k, v in value.items()}
            if isinstance(value, list):
                return [normalize(v) for v in value]
            return value

        serialized = []
        for info in media_files:
            normalized = {k: normalize(v) for k, v in info.items()}
            if 'path' in normalized and normalized['path'] is not None:
                normalized['path'] = str(normalized['path'])
            serialized.append(normalized)
        return serialized

    def _resolve_file_output_dir(self, media_info: Dict[str, Any]) -> Path:
        """Return the output directory for a specific file.

        In source mode, SRTs go next to each input file.
        Otherwise, all SRTs go to the single configured output_dir.
        """
        if self.source_output_mode:
            return Path(media_info['path']).parent
        return self.output_dir

    def _format_status(self, result: Optional[Dict[str, Any]]) -> str:
        """Render status for summary table."""
        if not result:
            return 'n/a'

        status = result.get('status', 'unknown')
        if status == 'completed':
            return 'completed'

        error = result.get('error')
        if not error:
            return status

        first_line = str(error).strip().splitlines()[0]
        if len(first_line) > 40:
            first_line = first_line[:37] + '...'
        return f"{status}: {first_line}"

    def _print_summary_table(self, rows: List[Dict[str, str]], duration: float) -> None:
        """Pretty-print a compact summary table for the batch run."""
        if not rows:
            logger.info("No files processed (elapsed %.1fs)", duration)
            return

        columns = [
            ('Pass1', 'pass1'),
            ('Pass2', 'pass2'),
            ('Merge', 'merge'),
            ('Final', 'final'),
        ]

        widths = {header: len(header) for header, _ in columns}
        for row in rows:
            for header, key in columns:
                widths[header] = max(widths[header], len(str(row.get(key, ''))))

        header_line = ' | '.join(header.ljust(widths[header]) for header, _ in columns)
        divider = '-+-'.join('-' * widths[header] for header, _ in columns)
        table_lines = [header_line, divider]
        for row in rows:
            table_lines.append(
                ' | '.join(str(row.get(key, '')).ljust(widths[header]) for header, key in columns)
            )

        table_output = '\n'.join(table_lines)
        logger.info("Ensemble summary (%.1fs)\n%s", duration, table_output)

    def _write_batch_summary(self, metadata_list: List[Dict[str, Any]]) -> Optional[Path]:
        """Persist a lightweight JSON summary for GUI/CLI consumers."""
        if not metadata_list:
            return None

        summary = {
            'generated_at': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            'files': [],
        }

        for item in metadata_list:
            summary['files'].append(
                {
                    'basename': item['input']['basename'],
                    'input_file': item['input']['file'],
                    'pass1': item.get('pass1'),
                    'pass2': item.get('pass2'),
                    'merge': item.get('merge'),
                    'final_output': item.get('summary', {}).get('final_output'),
                    'status': item.get('status', 'completed'),
                }
            )

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        summary_path = self.temp_dir / f"ensemble_summary_{timestamp}.json"
        try:
            summary_path.write_text(json.dumps(summary, indent=2), encoding='utf-8')
        except OSError as exc:
            logger.warning("Failed to write batch summary: %s", exc)
            return None

        return summary_path

    def _filter_picklable_kwargs(self, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Remove objects that cannot be pickled before sending to subprocesses.

        Also excludes 'parameter_tracer' which is handled separately via
        trace_file_path in the WorkerPayload. The worker creates its own
        tracer from the file path, so passing the tracer object would cause
        'got multiple values for keyword argument' errors.
        """
        # Keys to always exclude (handled separately or cause duplicate kwarg errors)
        excluded_keys = {'parameter_tracer', 'progress_display'}

        safe_kwargs = {}
        for key, value in kwargs.items():
            if key in excluded_keys:
                logger.debug("Excluding kwarg '%s' from worker (handled separately)", key)
                continue
            try:
                pickle.dumps(value)
            except Exception:
                logger.debug("Dropping non-picklable kwarg '%s' (%s)", key, type(value))
                continue
            safe_kwargs[key] = value
        return safe_kwargs

    def _create_ensemble_metadata(
        self,
        media_info: Dict,
        pass1_config: Dict[str, Any],
        pass2_config: Optional[Dict[str, Any]],
        merge_strategy: str
    ) -> Dict:
        """Create initial ensemble metadata structure."""
        return {
            'metadata_type': 'ensemble',
            'created_at': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            'input': {
                'file': str(media_info['path']),
                'basename': media_info['basename']
            },
            'configuration': {
                'pass1': pass1_config,
                'pass2': pass2_config,
                'merge_strategy': merge_strategy
            },
            'pass1': {'status': 'pending'},
            'pass2': {'status': 'pending' if pass2_config else 'disabled'},
            'merge': {'status': 'pending' if pass2_config else 'disabled'}
        }

    def _cleanup_intermediate(self, media_basename: str):
        """Clean up intermediate pass files."""
        try:
            # Clean pass-specific temp directories created by orchestrator and workers
            for suffix in ["pass1", "pass2", "pass1_worker", "pass2_worker"]:
                pass_temp = self.temp_dir / suffix
                if pass_temp.exists():
                    shutil.rmtree(pass_temp)
                    logger.debug(f"Cleaned up temp directory: {pass_temp.name}")

            # Optionally remove intermediate SRT files
            # Keep them for now for debugging - user can delete manually
        except Exception as e:
            logger.warning(f"Error during cleanup: {e}")

    def get_mode_name(self) -> str:
        """Return the mode name for this orchestrator."""
        return "ensemble"
