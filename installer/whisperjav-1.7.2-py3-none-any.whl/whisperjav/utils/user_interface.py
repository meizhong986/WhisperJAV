"""User interface utilities."""

class UserInterface:
    """Handle user interaction and progress display."""
    pass
