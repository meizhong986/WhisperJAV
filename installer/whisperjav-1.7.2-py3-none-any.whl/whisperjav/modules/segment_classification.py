"""Segment classification module."""

class SegmentClassifier:
    """Classify audio segments."""
    pass
